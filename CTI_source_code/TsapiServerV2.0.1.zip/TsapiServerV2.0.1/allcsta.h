// allcsta.h



#include "cstadefs.h"
#include "acsdefs.h"
#include "acs.h"
#include "csta.h"
#include "tdi.h"      // Novell TS_API
#include "alcatel_spec.h"
#ifdef USE_CSTAV2
#include "alcpriv2.h"
#endif //USE_CSTAV2
